import  {Component} from '@angular/core';

@Component({
	selector: 'my-employee3',
    templateUrl: './huser.component.html',
    styleUrls: ['./huser.component.css']
})
export class HuserComponent
{ 
}