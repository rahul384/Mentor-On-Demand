import  {Component} from '@angular/core';

@Component({
	selector: 'my-employee1',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent
{ 
}