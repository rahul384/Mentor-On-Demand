import  {Component} from '@angular/core';

@Component({
	selector: 'my-employee2',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.css']
})
export class SignupComponent
{ 
}