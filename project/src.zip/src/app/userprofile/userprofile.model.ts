export class Profile {

  id: number;
  userName : string;
  firstName: string;
  lastName: string;
  emailId: string;
  contactNumber : number;
  regCode : string;
  linkedinUrl : string;
  yearsOf_experience: string;

}





