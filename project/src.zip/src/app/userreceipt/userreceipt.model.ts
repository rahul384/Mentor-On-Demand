export class Payment {
  id : string;
  txnType: string;
  amount: number;
  remarks: string;
  mentorName: string;
  techName: string;
}
