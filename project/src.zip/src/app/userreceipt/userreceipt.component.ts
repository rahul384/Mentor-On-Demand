import  {Component} from '@angular/core';
import {Router} from '@angular/router';


import { Payment } from './userreceipt.model';
import { UserreceiptService } from './userreceipt.service';

@Component({
	selector: 'my-employee18',
    templateUrl: './userreceipt.component.html',
    styleUrls: ['./userreceipt.component.css']
})
export class UserreceiptComponent
{   
   
    payment: Payment[];
    showId=false;
    users=sessionStorage.getItem('fname');
    constructor(private router: Router, private userreceiptService: UserreceiptService)
	{

	}
    ngOnInit() {
        this.userreceiptService.getPayments()
          .subscribe( data => {
            this.payment = data;
          });
      };

      toggleId()
      {
          this.showId=!this.showId;
      }

    logout()
    {
        sessionStorage.removeItem('role');
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('fname');
        sessionStorage.removeItem('id');
        this.router.navigate(['home']);
        
    }
}