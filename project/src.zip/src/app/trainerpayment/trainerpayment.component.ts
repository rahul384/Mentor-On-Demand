import  {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import { Payment } from './trainerpayment.model';
import { TrainerpaymentService } from './trainerpayment.service';

@Component({
	selector: 'my-employee12',
    templateUrl: './trainerpayment.component.html',
    styleUrls: ['./trainerpayment.component.css']
})
export class TrainerpaymentComponent implements OnInit
{   
    payment: Payment[];
    displayId=false;
	withdrawAmount;
	amount;
	pid;
    users=sessionStorage.getItem('fname');
    constructor(private router: Router, private trainerpaymentService: TrainerpaymentService)
	{

	}

    ngOnInit() {
        this.trainerpaymentService.getPayments()
          .subscribe( data => {
            this.payment = data;
          });
      };

      
  Withdraw(amt){
    if(amt>this.amount)
    {
        alert("insufficient funds");
    }
    else
    {
        this.trainerpaymentService.Withdraw(this.pid,amt)
        .subscribe(data=>{
        alert("Withdraw Successfull");
        });
    
    }


}

      toggleId()
      {
          this.displayId=!this.displayId;
      }
  

    logout()
    {
        sessionStorage.removeItem('role');
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('fname');
        sessionStorage.removeItem('id');
        this.router.navigate(['home']);
        
    }
}