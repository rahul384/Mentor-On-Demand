export class Payment {
  id : string;
  txnType: string;
  amount: number;
  remarks: string;
  mentorName: string;
  techName: string;
  totalAmountToMentor: number;
  userId: string;
  trainingId: string;
 
}
