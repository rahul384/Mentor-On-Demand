export class Skill {
	
	id : number;
  name: string;
  toc: string;
  prerequisites: string;

}