export class Tech {
	id : number;
  techName: string;
  price: number;
  duration: string;
 

}