export class Prog {
	
	id : string;
  startDate: string;
  fees: number;
  mentorId: number;
  progress: number;
  rating: number;

}