export class Comt {
	
	id : string;
  startDate: string;
  fees: number;
  mentorId: number;
  progress: number;
  rating: number;

}